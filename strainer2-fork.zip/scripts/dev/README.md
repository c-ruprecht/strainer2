---
license: other
pretty_name: derep_high_qual-comp99-cont05-maxreps3000
tags: [metagenomics, bacterial-genomes, gut-microbiome, strain-detection, sourmash]
---

# derep_high_qual-comp99-cont05-maxreps3000

A dereplicated reference database of high-quality bacterial genomes, built for strain-level
detection and scrubbing in metagenomic data. It is provided at three dereplication thresholds
(98, 96 and 94%), together with a sourmash RocksDB index.

## How it was built

1. **Source genomes.** The starting set combines three sources: all genomes from GTDB, all
   genomes from UHGG, and isolate genomes from the Faith Lab (Icahn School of Medicine at
   Mount Sinai).
2. **Quality filter.** Only genomes with CheckM2 completeness above 99% and contamination
   below 0.5% were kept.
3. **Primary clusters.** Each genome was classified with sourmash against the GTDB RS232
   database. The classification defines the genome's primary cluster (`primary_cluster`),
   maximally 3000 genomes per cluster are used for derepelication to reduce very large clusters 
   of overrepresented lineages (E. coli, K. pneumoniae etc. ).
4. **Dereplication.** Within each primary cluster, genomes were compared pairwise with
   `genome_compare_presence`, which computes k-mer (k = 31) Jaccard similarity and
   containment. Genomes were then dereplicated at 98, 96 and 94% identity.
5. **Representative selection.** In each resulting cluster, isolate genomes are preferred
   over MAGs (`genome_type`). Among genomes of the same type, the one with the best CheckM2
   quality score (`score`) is chosen. Each GTDB RS232 lineage keeps at most 3,000
   representatives, which is what `maxreps3000` in the database name refers to.

| Threshold | Representatives |
|-----------|-----------------|
| 98%       | 181,756         |
| 96%       | 161,997         |
| 94%       | 148,878         |

The representatives at 96% and 94% are a subset of those at 98%. For that reason, only
`genomes_t98` holds genome files. `genomes_t96` and `genomes_t94` are rebuilt as symlinks
into it when the database is restored.

## Contents

| Path | Description |
|------|-------------|
| `genomes_t98/*.tar` | 98% representatives (`.fna.gz`), sharded into tar archives |
| `rocksdb/` | sourmash RocksDB index of the database (split archive) |
| `summaries/` | cluster, representative, lineage and species tables for each threshold |
| `manifest/`, `MANIFEST.json` | file inventory and checksums used by the restore script |

`summaries/representatives_t*.tsv` has one row per representative. The columns include
the GTDB taxonomy, primary cluster, cluster size, minimum within-cluster k-mer identity and
ANI, CheckM2 completeness and contamination, genome length, and source (`GTDB`, `UHGG`,
`faith_lab_isolate`). The `genome_path` column holds the original build paths. The restore
script rewrites these to the restored location.

## Download and restore

```bash
conda install -c conda-forge huggingface_hub hf-xet
python scrubdb_hf.py pull --repo <user>/<repo> \
    --download-dir ./dl --dest ./derep_high_qual-comp99-cont05-maxreps3000 --cleanup
```

The restore script verifies every archive checksum. It then unpacks the genomes, rebuilds
`genomes_t96` and `genomes_t94`, and checks the result.

## Citation and licenses

Please cite GTDB, UHGG, sourmash and CheckM2 when using this database. Genomes from GTDB and
UHGG are subject to the terms of those resources.
