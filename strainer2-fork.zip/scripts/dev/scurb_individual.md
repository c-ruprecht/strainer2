cd /metrica/codebase/strainer2-fork/test/strainer2_parallel
mkdir -p /metrica/scratch/presence_t

/metrica/codebase/strainer2-fork/src/kmer_scrub_count_individual \
-r /metrica/codebase/strainer2-fork/test/strainer2_parallel/strains/Bacteroides_ovatus_1001283st1_B8_1001283B150210_160208.fna.gz \
-A /metrica/codebase/strainer2-fork/test/strainer2_parallel/genomes_to_scrub.txt \
-T 0.96 \
-P 10 \
-o /metrica/scratch/presence_t/indiv10.tsv.zst \
-S /metrica/scratch/presence_t/summary \
-t 30 | gzip --best > /metrica/scratch/presence_t/globals.scrub_kmer_counts.gz


