import os

input_folder = '/metrica/scratch/strainer_dev/in_vitro_LBspike'
strainer_dir = '/metrica/codebase/strainer2-fork'
drug_genome_lists='/metrica/codebase/metrica-tools/workflows/strainer/in_vitro/genome_lists'

# Build dict: drug_name -> list of strains
dict_drugmix = {}
for f in os.listdir(drug_genome_lists):
    if f.endswith('.genome_list.txt'):
        drug_name = f[:-len('.genome_list.txt')]
        with open(f'{drug_genome_lists}/{f}') as fh:
            dict_drugmix[drug_name] = [line.strip() for line in fh if line.strip()]

drug_list = list(dict_drugmix.keys())
# All (drug, strain) pairs for rule all expansion
drug_strain_pairs_all = [(drug, strain) for drug, strains in dict_drugmix.items() for strain in strains]

drug_strain_pairs = [
    (drug, strain) for drug, strain in drug_strain_pairs_all
    if os.path.isfile(f'{input_folder}/{drug}/{strain}/scrubbed_kmers/{strain}.rare_kmers_mapped.tsv.gz')
    and os.path.isfile(f'{input_folder}/{drug}/{strain}/strain_detect/{strain}.kmer_hits.tsv.gz')
]

stripped = set(drug_strain_pairs_all) - set(drug_strain_pairs)
if stripped:
    print(f"Skipping {len(stripped)} pairs with missing input files: {sorted(stripped)}")
print(f"Running {len(drug_strain_pairs)} pairs")
rule all:
    input:
        [input_folder + f'/{drug}/{strain}/coverage_depth/coverage_depth.tsv' for drug, strain in drug_strain_pairs]

rule coverage_depth:
    input:
        location = input_folder + '/{drug}/{strain}/scrubbed_kmers/{strain}.rare_kmers_mapped.tsv.gz',
        hits = input_folder + '/{drug}/{strain}/strain_detect/{strain}.kmer_hits.tsv.gz'
    output:
        cov = input_folder+'/{drug}/{strain}/coverage_depth/coverage_depth.tsv'
    params:
        output_dir = input_folder+'/{drug}/{strain}/coverage_depth',
        script = strainer_dir+'/scripts/coverage_depth_locations.py'
    shell:
        '''
        conda run -n strainer2_env python {params.script} \
        --location {input.location} \
        --hits {input.hits} \
        --output_dir {params.output_dir}
        '''