# packing of database
DB=/sc/arion/projects/faithj02a/Constantin/databases/derep_high_qual-comp99-cont05-maxreps3000
RDB=/sc/arion/projects/faithj02a/Constantin/sourmash/derep_high_qual-comp99-cont05-maxreps3000/derep_high_qual-comp99-cont05-maxreps3000.rocksdb
STAGE=/sc/arion/projects/faithj02a/Constantin/scrub_db_hf

ml anaconda3/latest
conda activate strainer2_env
conda install -c conda-forge huggingface_hub hf-xet zstd

python /hpc/users/ruprec02/git/strainer2/scripts/scrubdb_hf.py pack --db-dir $DB --rocksdb $RDB --staging $STAGE --dry-run

# run packing on interactive node
bsub -P acc_faithj02a -q premium -n 13 -W 12:00 \
  -R "span[hosts=1]" -R "rusage[mem=2000]" \
  -J scrubdb_pack -o pack.%J.log -e pack.%J.err \
  conda run --no-capture-output -n strainer2_env \
  python /hpc/users/ruprec02/git/strainer2/scripts/scrubdb_hf.py pack \
    --db-dir $DB --rocksdb $RDB --staging $STAGE --threads 13 --jobs 11

- add readme file to directory
- removed summaries that are not wanted
rewrite manifest
STAGE=/sc/arion/projects/faithj02a/Constantin/scrub_db_hf
python -c "import json,os; p='$STAGE/MANIFEST.json'; m=json.load(open(p)); m['summaries']=sorted(os.listdir('$STAGE/summaries')); json.dump(m,open(p,'w'),indent=2); print(m['summaries'])"

- remove minerva paths etc from manifest and tsv rep files
- removed FTP_download column as well


# uploading to hf
bsub -q express -P acc_faithj02a -n 8 -R "rusage[mem=32000]" -W 12:00 -Is /bin/bash

ml proxies/1
ml anaconda3/latest
conda activate strainer2_env
export HF_HOME=/sc/arion/scratch/ruprec02/hf_home  
hf auth login                     # paste a token with *write* access
hf auth whoami                    # should print your username


conda run --no-capture-output -n strainer2_env \
python /hpc/users/ruprec02/git/strainer2/scripts/scrubdb_hf.py upload \
--staging /sc/arion/projects/faithj02a/Constantin/scrub_db_hf \
--repo cruprecht/scrubdb-derep-hq-comp99-cont05 \
--public --tag v2026.09 --workers 8