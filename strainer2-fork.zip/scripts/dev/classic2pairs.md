/metrica/codebase/strainer2-fork/scripts/kmer_scrub_filter_pairs.py \
--basename "Bacteroides_dorei_WAS_Bacteroides_vulgatus_MSSM.1001099B_141215_G4" \
--counts_summary /metrica/scratch/classic_pairs/scrub_counts/scrub_sample.summary.tsv \
--counts_global /metrica/scratch/classic_pairs/scrub_counts/kmer_scrub_counts.txt.gz \
--counts_individual /metrica/scratch/classic_pairs/scrub_counts/per_sample.kmer_scrub_counts.tsv.zst \
--output-dir /metrica/scratch/classic_pairs/kmer_pairs \
--create_classic_pairs \
--scrubbed_kmers /metrica/scratch/classic_pairs/Bacteroides_dorei_WAS_Bacteroides_vulgatus_MSSM.1001099B_141215_G4.scrubbed_kmers \
--threads 20 \
--pair_mode sxs 

/metrica/codebase/strainer2-fork/scripts/kmer_scrub_filter_pairs.py \
--basename "Bacteroides_dorei_WAS_Bacteroides_vulgatus_MSSM.1001099B_141215_G4" \
--counts_summary /metrica/scratch/classic_pairs/scrub_counts/scrub_sample.summary.tsv \
--counts_global /metrica/scratch/classic_pairs/scrub_counts/kmer_scrub_counts.txt.gz \
--counts_individual /metrica/scratch/classic_pairs/scrub_counts/per_sample.kmer_scrub_counts.tsv.zst \
--output-dir /metrica/scratch/classic_pairs/kmer_pairs \
--create_classic_pairs \
--scrubbed_kmers /metrica/scratch/classic_pairs/short.scrubbed_kmers \
--threads 20 \
--pair_mode sxs 


/metrica/codebase/strainer2-fork/scripts/kmer_scrub_filter_pairs.py \
--genome /metrica/scratch/classic_pairs/Bacteroides_dorei_WAS_Bacteroides_vulgatus_MSSM.1001099B_141215_G4.fna.gz \
--basename "Bacteroides_dorei_WAS_Bacteroides_vulgatus_MSSM.1001099B_141215_G4" \
--counts_summary /metrica/scratch/classic_pairs/scrub_counts/scrub_sample.summary.tsv \
--counts_global /metrica/scratch/classic_pairs/scrub_counts/kmer_scrub_counts.txt.gz \
--counts_individual /metrica/scratch/classic_pairs/scrub_counts/per_sample.kmer_scrub_counts.tsv.zst \
--output-dir /metrica/scratch/classic_pairs/kmer_pairs \
--create_classic_pairs \
--scrubbed_kmers /metrica/scratch/classic_pairs/Bacteroides_dorei_WAS_Bacteroides_vulgatus_MSSM.1001099B_141215_G4.scrubbed_kmers \
--threads 20 \
--pair_mode sxs 

# create pairs
/metrica/codebase/strainer2-fork/scripts/kmer_scrub_filter_pairs.py \
--basename "Bacteroides_cellulosilyticus_WAS_Bacteroides_intestinalis_MSSM.1001262B_160229_E2" \
--counts_summary /metrica/scratch/classic_pairs/scrub_counts/scrub_sample.summary.tsv \
--counts_global /metrica/scratch/classic_pairs/scrub_counts/kmer_scrub_counts.txt.gz \
--counts_individual /metrica/scratch/classic_pairs/scrub_counts/per_sample.kmer_scrub_counts.tsv.zst \
--output-dir /metrica/scratch/classic_pairs/kmer_pairs \
--create_classic_pairs \
--scrubbed_kmers /metrica/scratch/classic_pairs/Bacteroides_cellulosilyticus_WAS_Bacteroides_intestinalis_MSSM.1001262B_160229_E2.scrubbed_kmers \
--threads 20 \
--pair_mode sxs

# coverage pairs
python /metrica/codebase/strainer2-fork/scripts/coverage_depth_pairs.py \
--hits /metrica/scratch/classic_pairs/Bacteroides_cellulosilyticus_WAS_Bacteroides_intestinalis_MSSM.1001262B_160229_E2.kmer_hits.tsv.gz \
--output_dir  /metrica/scratch/classic_pairs/coverage_pairs \
--inform_kmers /metrica/scratch/classic_pairs/kmer_pairs 




# pairs rewrite
/metrica/codebase/strainer2-fork/scripts/kmer_scrub_filter_pairs.py \
--genome /metrica/scratch/classic_pairs/Bacteroides_cellulosilyticus_WAS_Bacteroides_intestinalis_MSSM.1001262B_160229_E2.fna.gz \
--basename "Bacteroides_cellulosilyticus_WAS_Bacteroides_intestinalis_MSSM.1001262B_160229_E2.kmer_hits" \
--counts_summary /metrica/scratch/classic_pairs/scrub_counts/scrub_sample.summary.tsv \
--counts_global /metrica/scratch/classic_pairs/scrub_counts/kmer_scrub_counts.txt.gz \
--counts_individual /metrica/scratch/classic_pairs/scrub_counts/per_sample.kmer_scrub_counts.tsv.zst \
--output-dir /metrica/scratch/pairs/kmer_pairs-sxs \
--threads 20 \
--pair_mode sxs



# get individual coverage

python /metrica/codebase/strainer2-fork/scripts/coverage_depth_pairs.py \
--hits /metrica/scratch/classic_pairs/Bacteroides_cellulosilyticus_WAS_Bacteroides_intestinalis_MSSM.1001262B_160229_E2.kmer_hits.tsv.gz \
--output_dir  /metrica/scratch/pairs/coverage_pairs \
--inform_kmers /metrica/scratch/pairs/kmer_pairs-sxs 