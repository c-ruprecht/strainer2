python /metrica/codebase/strainer2-fork/scripts/kmer_scrub_filter2.py \
/metrica/projects/faith/strainer/20260401_invitro/strains/genome_assemblies/ATCC20/ATCC20_Escherichia_coli_ATCC700926.fna.gz \
/metrica/scratch/strainer_dev/in_vitro_low-union/ATCC20/ATCC20_Escherichia_coli_ATCC700926/kmer_scrub_counts.txt.gz \
--output-dir /metrica/scratch/strainer_dev/test_independent \
--independent --percentile_union 0.05 --percentile 0.001 --figures

# independent scrub
- removes terminal kmers
- removes non ACGT containing kmers
- then bins genomes to kmer size 31
- allows only rare kmers per contig in relation to contig size
- drops duplicates per kmer bin and keeps the one with rarest kmers
- loops over the dataframe and finds kmers that still overlap at borders of bins, taking into account the orientation of the kmer neighbor
- if more kmers are on a contig than allowed it takes a subset of lowest counts for kmers

# Create kmer pairs 
1. backmap the rare kmers to the scrub genomes
src/kmer_strain_detect_genome \
-k /metrica/scratch/strainer_dev/test_independent/ATCC20_Escherichia_coli_ATCC700926.rare_kmers_mapped.tsv.gz \
-B /metrica/codebase/strainer2-fork/scripts/dev/remapping_scrubdb.txt \
-o /metrica/scratch/strainer_dev/test_independent/ATCC20_Escherichia_coli_ATCC700926.remapped.tsv.gz \
-j 30

# Creating full pair sets and then counting 
 python scripts/kmer_pairs.py \
 --csv_path /metrica/scratch/strainer_dev/test_independent/ATCC20_Escherichia_coli_ATCC700926.remapped.tsv.gz \
--output_dir /metrica/scratch/strainer_dev/test_independent/kmer_pairs2
--ref_jaccard_threshold

 # mapping rare kmers to target metagenomic sequencing
 src/kmer_strain_detect \
-k /metrica/scratch/strainer_dev/test_independent/ATCC20_Escherichia_coli_ATCC700926.rare_kmers_mapped.tsv.gz \
-B /metrica/codebase/strainer2-fork/test/invitro_mixes/target_metagenomes.tsv \
-o /metrica/scratch/strainer_dev/test_independent/ATCC20_Escherichia_coli_ATCC700926.kmer_hits.gz \
-j 30

# Get coverage calls
- get general coverage for all kmers per sample
- get coverage for all kmer_pairs
- maybe include weights for all 

python scripts/coverage_depth_pairs.py \
--location /metrica/scratch/strainer_dev/test_independent/ATCC20_Escherichia_coli_ATCC700926.rare_kmers_mapped.tsv.gz \
--hits /metrica/scratch/strainer_dev/test_independent/ATCC20_Escherichia_coli_ATCC700926.kmer_hits.gz \
--inform_kmers /metrica/scratch/strainer_dev/test_independent/kmer_pairs2/ \
--output_dir /metrica/scratch/strainer_dev/test_independent/coverage 


python scripts/coverage_depth_pairs.py \
--location /metrica/scratch/strainer_dev/invitro_pairs2/MTC01/MTC01.01_Bacteroides_uniformis_1001283st1_C6_1001283B150304_161114/scrubbed_kmers/MTC01.01_Bacteroides_uniformis_1001283st1_C6_1001283B150304_161114.rare_kmers_mapped.tsv.gz \
--hits /metrica/scratch/strainer_dev/invitro_pairs2/MTC01/MTC01.01_Bacteroides_uniformis_1001283st1_C6_1001283B150304_161114/strain_detect/MTC01.01_Bacteroides_uniformis_1001283st1_C6_1001283B150304_161114.kmer_hits.tsv.gz \
--inform_kmers /metrica/scratch/strainer_dev/invitro_pairs2/MTC01/MTC01.01_Bacteroides_uniformis_1001283st1_C6_1001283B150304_161114/kmer_pairs \
--output_dir /metrica/scratch/strainer_dev/invitro_pairs2/MTC01/MTC01.01_Bacteroides_uniformis_1001283st1_C6_1001283B150304_161114/coverage 

# tsting when do i get triplets
# Creating full pair sets and then counting 
- still non informative but not sure if that means they are 
python scripts/kmer_pairs.py \
--csv_path /metrica/scratch/strainer_dev/test_independent/ATCC20_Escherichia_coli_ATCC700926.remapped.tsv.gz \
--output_dir /metrica/scratch/strainer_dev/test_independent/kmer_pairs3 \
--ref_jaccard_threshold 0.99 \
--threads 28

python scripts/kmer_pairs.py --output_dir /metrica/scratch/strainer_dev/test_independent/ --testmode

python scripts/coverage_depth_pairs.py \
--location /metrica/scratch/strainer_dev/test_independent/ATCC20_Escherichia_coli_ATCC700926.rare_kmers_mapped.tsv.gz \
--hits /metrica/scratch/strainer_dev/test_independent/ATCC20_Escherichia_coli_ATCC700926.kmer_hits.gz \
--inform_kmers /metrica/scratch/strainer_dev/test_independent/kmer_pairs3/ \
--output_dir /metrica/scratch/strainer_dev/test_independent/coverage3 


# Try donwload large scrub db to check scrubbing on mtc01
 python scripts/build_scrub_db_claude.py --drug /metrica/codebase/strainer2-fork/scripts/dev/sourmash_gather_drug_mtc.csv \
 --target_samples /metrica/codebase/strainer2-fork/scripts/dev/targetsample_sourmash_gather.csv \
 --kmer_ident 0.98 \
 --min_jaccard 0.85 \
 --scrub_db_path /metrica/scratch/strainer_dev/scrub_db_mtc \
 --genome_compare src/genome_compare \
 --rank_limits 1000 1000 1000 1000

 ## Local scrub full
 src/kmer_scrub_count_individual \
-r  /metrica/projects/faith/strainer/20260401_invitro/strains/genome_assemblies/LBmixes/MTC01.01_Bacteroides_uniformis_1001283st1_C6_1001283B150304_161114.fna.gz \
-A /metrica/codebase/strainer2-fork/scripts/dev/remapping_scrubdb.txt \
-B /metrica/codebase/strainer2-fork/test/invitro_mixes/scrub_db/metagenomes.txt \
-C /metrica/codebase/strainer2-fork/scripts/dev/mtc01.drug_list \
-p /metrica/scratch/strainer_dev/kmer_pairs_uniform/kmer_scrub_counts/kmer_scrub.progress \
-o /metrica/scratch/strainer_dev/kmer_pairs_uniform/kmer_scrub_counts/individual.kmer_counts.tsv.zst \
-S /metrica/scratch/strainer_dev/kmer_pairs_uniform/kmer_scrub_counts/per_sample_summary.tsv \
-t 30 \
-T 0.96 | gzip --best > /metrica/scratch/strainer_dev/kmer_pairs_uniform/kmer_scrub_counts/global.kmer_counts.tsv.gz
 
 - right now only the global count is filtered but these samples are still in the presence list for pairs
 - need to be removed manually 
 
 ## Filter
 python -u scripts/kmer_scrub_filter_pairs.py \
 --genome /metrica/projects/faith/strainer/20260401_invitro/strains/genome_assemblies/LBmixes/MTC01.01_Bacteroides_uniformis_1001283st1_C6_1001283B150304_161114.fna.gz \
 --counts_global /metrica/scratch/strainer_dev/kmer_pairs_uniform/kmer_scrub_counts/global.kmer_counts.tsv.gz \
 --counts_individual /metrica/scratch/strainer_dev/kmer_pairs_uniform/kmer_scrub_counts/individual.kmer_counts.tsv.zst \
 --counts_summary /metrica/scratch/strainer_dev/kmer_pairs_uniform/kmer_scrub_counts/per_sample_summary.tsv \
 --output-dir /metrica/scratch/strainer_dev/kmer_pairs_uniform/kmer_pairs \
 --basename MTC01.01_Bacteroides_uniformis_1001283st1_C6_1001283B150304_161114 \
 --figures \
 --threads 12 \
 --presence_t 10

 ## coverage
 python -u scripts/coverage_depth_pairs.py \
 --location /metrica/scratch/strainer_dev/kmer_pairs_uniform/kmer_pairs/MTC01.01_Bacteroides_uniformis_1001283st1_C6_1001283B150304_161114.rare_kmers_mapped.tsv.gz \
 --hits /metrica/scratch/strainer_dev/kmer_pairs_uniform/strain_detect/MTC01.01_Bacteroides_uniformis_1001283st1_C6_1001283B150304_161114.kmer_hits.tsv.gz \
 --inform_kmers /metrica/scratch/strainer_dev/kmer_pairs_uniform/kmer_pairs \
 --output_dir /metrica/scratch/strainer_dev/kmer_pairs_uniform/coverage