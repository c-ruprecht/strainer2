import os

out_dir = '/metrica/scratch/strainer_dev/in_vitro_pairs'
strainer_dir = '/metrica/codebase/strainer2-fork'
drug_genome_lists='/metrica/codebase/metrica-tools/workflows/strainer/in_vitro/genome_lists'

# Build dict: drug_name -> list of strains
dict_drugmix = {}
for f in os.listdir(drug_genome_lists):
    if f.endswith('.genome_list.txt'):
        drug_name = f[:-len('.genome_list.txt')]
        with open(f'{drug_genome_lists}/{f}') as fh:
            dict_drugmix[drug_name] = [line.strip() for line in fh if line.strip()]

drug_list = list(dict_drugmix.keys())
# All (drug, strain) pairs for rule all expansion
drug_strain_pairs_all = [(drug, strain) for drug, strains in dict_drugmix.items() for strain in strains]

drug_strain_pairs = [
    (drug, strain) for drug, strain in drug_strain_pairs_all
    if os.path.isfile(f'{out_dir}/{drug}/{strain}/scrubbed_kmers/{strain}.rare_kmers_mapped.tsv.gz')
    and os.path.isfile(f'{out_dir}/{drug}/{strain}/strain_detect/{strain}.kmer_hits.tsv.gz')
]

stripped = set(drug_strain_pairs_all) - set(drug_strain_pairs)
if stripped:
    print(f"Skipping {len(stripped)} pairs with missing input files: {sorted(stripped)}")
print(f"Running {len(drug_strain_pairs)} pairs")
rule all:
    input:
        [out_dir + f'/{drug}/{strain}/coverage_depth/coverage_depth.tsv' for drug, strain in drug_strain_pairs]

rule kmer_pairs:
    input:
        remapped = out_dir + '/{drug}/{strain}/kmer_pairs/{strain}.remapped.tsv.gz'
    output:
        # sentinel written by the script / by the rule itself so downstream rules can depend on completion
        done              = out_dir + '/{drug}/{strain}/kmer_pairs/{strain}.done',
        inform_singletons = out_dir + '/{drug}/{strain}/kmer_pairs/{strain}.inform_kmer_singleton.parquet',
        inform_pairs      = out_dir + '/{drug}/{strain}/kmer_pairs/{strain}.inform_kmer_pairs.parquet'
    log:
        out_dir + '/logs/kmer_pairs/{drug}/{strain}.log'
    params:
        script     = strainer_dir + '/scripts/kmer_pairs.py',
        output_dir = out_dir + '/{drug}/{strain}/kmer_pairs',
        ref_jaccard_threshold = config.get('ref_jaccard_threshold', 0.95),
        basename = '{strain}'
    threads: 6 
    shell:
        '''
        echo "[$(date)] kmer_pairs drug={wildcards.drug} strain={wildcards.strain}" > {log}
        conda run -n strainer2_env python {params.script} \
            --csv_path {input.remapped} \
            --output_dir {params.output_dir} \
            --threads {threads} \
            --ref_jaccard_threshold {params.ref_jaccard_threshold} \
            --basename {params.basename}
            >> {log} 2>&1
        touch {output.done}
        echo "[$(date)] done" >> {log}
        '''


rule coverage_depth:
    input:
        location = out_dir + '/{drug}/{strain}/scrubbed_kmers/{strain}.rare_kmers_mapped.tsv.gz',
        hits = out_dir + '/{drug}/{strain}/strain_detect/{strain}.kmer_hits.tsv.gz',
        inform = out_dir + '/{drug}/{strain}/kmer_pairs/{strain}.done'
    output:
        cov = out_dir+'/{drug}/{strain}/coverage_depth/coverage_depth.tsv'
    params:
        output_dir = out_dir+'/{drug}/{strain}/coverage_depth',
        script = strainer_dir+'/scripts/coverage_depth_pairs.py',
        inform_kmers = out_dir+'/{drug}/{strain}/kmer_pairs/'
    shell:
        '''
        conda run -n strainer2_env python {params.script} \
        --location {input.location} \
        --hits {input.hits} \
        --output_dir {params.output_dir} \
        --inform_kmers {params.inform_kmers}
        '''